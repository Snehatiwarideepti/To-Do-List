import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

class Task {
    String text;
    boolean completed;
    LocalDate dueDate;
    Task(String text, LocalDate dueDate) {
        this.text = text;
        this.completed = false;
        this.dueDate = dueDate;
    }
}

class TaskListModel extends AbstractListModel<Task> {
    private final List<Task> allTasks = new ArrayList<>();
    private List<Task> filteredTasks = new ArrayList<>();
    private String search = "";
    private Comparator<Task> sortComparator = Comparator.comparing(t -> t.text.toLowerCase());

    public TaskListModel() {
        updateFilterAndSort();
    }
    public int getSize() { return filteredTasks.size(); }
    public Task getElementAt(int i) { return filteredTasks.get(i); }
    public void addTask(Task t) { allTasks.add(t); updateFilterAndSort(); fireContentsChanged(this, 0, getSize()); }
    public void removeTask(int i) { allTasks.remove(filteredTasks.get(i)); updateFilterAndSort(); fireContentsChanged(this, 0, getSize()); }
    public void toggleTask(int i) { filteredTasks.get(i).completed = !filteredTasks.get(i).completed; fireContentsChanged(this, i, i); }
    public void editTask(int i, String newText, LocalDate newDueDate) {
        Task t = filteredTasks.get(i);
        t.text = newText;
        t.dueDate = newDueDate;
        fireContentsChanged(this, i, i);
    }
    public void setSearch(String s) { search = s.toLowerCase(); updateFilterAndSort(); fireContentsChanged(this, 0, getSize()); }
    public void setSortComparator(Comparator<Task> comp) { sortComparator = comp; updateFilterAndSort(); fireContentsChanged(this, 0, getSize()); }
    private void updateFilterAndSort() {
        filteredTasks = new ArrayList<>();
        for (Task t : allTasks) {
            if (t.text.toLowerCase().contains(search)) filteredTasks.add(t);
        }
        filteredTasks.sort(sortComparator);
    }
}

class TaskRenderer extends JPanel implements ListCellRenderer<Task> {
    private final JCheckBox checkBox = new JCheckBox();
    private final JTextArea label = new JTextArea();
    private final JLabel dateLabel = new JLabel();
    private static final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    public TaskRenderer() {
        setLayout(new BorderLayout(8, 0));
        setOpaque(true);
        checkBox.setOpaque(false);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        label.setLineWrap(true);
        label.setWrapStyleWord(true);
        label.setOpaque(false);
        label.setEditable(false);
        label.setFocusable(false);
        label.setBorder(null);
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        dateLabel.setForeground(new Color(120, 120, 120));
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setOpaque(false);
        centerPanel.add(label, BorderLayout.CENTER);
        centerPanel.add(dateLabel, BorderLayout.SOUTH);
        add(checkBox, BorderLayout.WEST);
        add(centerPanel, BorderLayout.CENTER);
        setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
    }
    @Override
    public Component getListCellRendererComponent(JList<? extends Task> list, Task value, int index, boolean isSelected, boolean cellHasFocus) {
        checkBox.setSelected(value.completed);
        String displayText = value.text != null && !value.text.trim().isEmpty() ? "\u2022  " + value.text : "\u2022  (No Task Name)";
        label.setText(displayText);
        label.setForeground(value.completed ? new Color(160, 160, 160) : new Color(40, 40, 40));
        label.setFont(label.getFont().deriveFont(value.completed ? Font.ITALIC : Font.PLAIN));
        label.setToolTipText(value.text);
        if (value.dueDate != null) {
            dateLabel.setText("Due: " + value.dueDate.format(fmt));
            if (!value.completed && value.dueDate.isBefore(LocalDate.now())) {
                dateLabel.setForeground(new Color(220, 20, 60));
            } else {
                dateLabel.setForeground(new Color(120, 120, 120));
            }
        } else {
            dateLabel.setText("");
        }
        setBackground(isSelected ? new Color(230, 240, 255) : new Color(255, 255, 255, 0));
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(2, 2, 2, 2),
            BorderFactory.createLineBorder(new Color(240, 240, 240), 1, true)
        ));
        return this;
    }
}

class RoundedButton extends JButton {
    public RoundedButton(String text, Color bgColor, Color fgColor) {
        super(text);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setForeground(fgColor);
        setBackground(bgColor);
        setFont(new Font("Segoe UI", Font.BOLD, 13));
        setBorder(BorderFactory.createEmptyBorder(5, 14, 5, 14));
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getModel().isRollover() ? getBackground().darker() : getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
        super.paintComponent(g);
        g2.dispose();
    }
    @Override
    public void paintBorder(Graphics g) {}
    @Override
    public boolean isOpaque() { return false; }
}

public class ToDoListApp extends JFrame {
    private TaskListModel taskListModel;
    private JList<Task> taskList;
    private JTextField taskField, searchField;
    private RoundedButton addButton, removeButton;
    private JLabel titleLabel;
    private JComboBox<String> sortBox;
    private String placeholder = "Add a new task...";
    private static final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public ToDoListApp() {
        setTitle("To-Do List App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(420, 410);
        setLocationRelativeTo(null);
        setContentPane(new GradientPanel());
        setLayout(new BorderLayout());


        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setOpaque(false);


        titleLabel = new JLabel("To-Do List", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleLabel.setForeground(new Color(40, 40, 40));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(18, 0, 8, 0));
        topPanel.add(titleLabel);


        JPanel searchSortPanel = new JPanel();
        searchSortPanel.setLayout(new BoxLayout(searchSortPanel, BoxLayout.X_AXIS));
        searchSortPanel.setOpaque(false);
        searchSortPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        searchField = new JTextField();
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 210, 210), 1, true),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        searchField.setPreferredSize(new Dimension(120, 28));
        searchField.setMaximumSize(new Dimension(120, 28));
        searchField.setMinimumSize(new Dimension(70, 28));
        searchField.setToolTipText("Search tasks");

        String[] sortOptions = {"Name", "Due", "Done"};
        sortBox = new JComboBox<>(sortOptions);
        sortBox.setFont(new Font("Segoe UI", Font.BOLD, 12));
        sortBox.setPreferredSize(new Dimension(130, 28));
        sortBox.setMaximumSize(new Dimension(130, 28));
        sortBox.setMinimumSize(new Dimension(130, 28));
        sortBox.setBackground(Color.WHITE);
        sortBox.setFocusable(false);
        sortBox.setBorder(BorderFactory.createEmptyBorder(4, 18, 4, 18));

        searchSortPanel.add(searchField);
        searchSortPanel.add(Box.createRigidArea(new Dimension(12, 0)));
        searchSortPanel.add(sortBox);
        searchSortPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        topPanel.add(searchSortPanel);
        add(topPanel, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setOpaque(false);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));

        taskListModel = new TaskListModel();
        taskList = new JList<>(taskListModel);
        taskList.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        taskList.setCellRenderer(new TaskRenderer());
        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(taskList);
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(0, 0, 0, 0),
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230), 1, true),
                BorderFactory.createEmptyBorder(0, 0, 0, 0)
            )
        ));
        scrollPane.setPreferredSize(new Dimension(360, 180));
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        mainPanel.add(scrollPane);


        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.X_AXIS));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        inputPanel.setOpaque(false);
        taskField = new JTextField(placeholder);
        taskField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        taskField.setForeground(Color.GRAY);
        taskField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 210, 210), 1, true),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        taskField.setPreferredSize(new Dimension(180, 28));
        taskField.setMaximumSize(new Dimension(Short.MAX_VALUE, 28));
        taskField.setMinimumSize(new Dimension(60, 28));

        javax.swing.event.DocumentListener clearPlaceholderListener = new javax.swing.event.DocumentListener() {
            private void clear() {
                if (taskField.getText().equals(placeholder)) {
                    taskField.setText("");
                    taskField.setForeground(Color.BLACK);
                }
            }
            public void insertUpdate(javax.swing.event.DocumentEvent e) { clear(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) {}
            public void changedUpdate(javax.swing.event.DocumentEvent e) {}
        };
        taskField.getDocument().addDocumentListener(clearPlaceholderListener);
        taskField.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (taskField.getText().equals(placeholder)) {
                    taskField.setText("");
                    taskField.setForeground(Color.BLACK);
                }
            }
            public void focusLost(FocusEvent e) {
                if (taskField.getText().isEmpty()) {
                    taskField.setText(placeholder);
                    taskField.setForeground(Color.GRAY);
                }
            }
        });
        addButton = new RoundedButton("Add", new Color(60, 179, 113), Color.WHITE);
        addButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addButton.setPreferredSize(new Dimension(90, 28));
        addButton.setMaximumSize(new Dimension(90, 28));
        addButton.setMinimumSize(new Dimension(60, 28));
        addButton.setBorder(BorderFactory.createEmptyBorder(4, 18, 4, 18));
        inputPanel.add(taskField);
        inputPanel.add(Box.createRigidArea(new Dimension(8, 0)));
        inputPanel.add(addButton);
        mainPanel.add(inputPanel);


        JPanel cardPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int arc = 24;
                int shadow = 10;
                g2.setColor(new Color(0,0,0,20));
                g2.fillRoundRect(shadow, shadow, getWidth()-shadow*2, getHeight()-shadow*2, arc, arc);
                g2.setColor(new Color(255,255,255,245));
                g2.fillRoundRect(0, 0, getWidth()-shadow, getHeight()-shadow, arc, arc);
                g2.dispose();
            }
        };
        cardPanel.setOpaque(false);
        cardPanel.setLayout(new BorderLayout());
        cardPanel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        cardPanel.add(mainPanel, BorderLayout.CENTER);
        add(cardPanel, BorderLayout.CENTER);


        removeButton = new RoundedButton("Remove", new Color(240, 80, 80), Color.WHITE);
        removeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        removeButton.setPreferredSize(new Dimension(90, 36));
        removeButton.setMaximumSize(new Dimension(90, 36));
        removeButton.setMinimumSize(new Dimension(90, 36));
        removeButton.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
        JPanel removePanel = new JPanel();
        removePanel.setOpaque(false);
        removePanel.setBorder(BorderFactory.createEmptyBorder(0, 12, 8, 12));
        removePanel.add(removeButton);
        add(removePanel, BorderLayout.SOUTH);


        addButton.addActionListener(e -> addTaskDialog());
        taskField.addActionListener(e -> addTaskDialog());


        removeButton.addActionListener(e -> removeTask());


        taskList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int index = taskList.locationToIndex(e.getPoint());
                if (index != -1) {
                    Rectangle rect = taskList.getCellBounds(index, index);
                    if (rect != null && e.getX() - rect.x < 30) { // Click near checkbox
                        taskListModel.toggleTask(index);
                    }
                }
            }
        });


        taskList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = taskList.locationToIndex(e.getPoint());
                    if (index != -1) {
                        editTaskDialog(index);
                    }
                }
            }
        });


        searchField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { update(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { update(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { update(); }
            private void update() {
                taskListModel.setSearch(searchField.getText());
            }
        });


        sortBox.addActionListener(e -> {
            int idx = sortBox.getSelectedIndex();
            Comparator<Task> comp;
            if (idx == 0) comp = Comparator.comparing(t -> t.text.toLowerCase());
            else if (idx == 1) comp = Comparator.comparing((Task t) -> t.dueDate == null ? LocalDate.MAX : t.dueDate);
            else comp = Comparator.comparing((Task t) -> t.completed).thenComparing(t -> t.text.toLowerCase());
            taskListModel.setSortComparator(comp);
        });


        addButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addButton.setBackground(new Color(46, 160, 100));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addButton.setBackground(new Color(60, 179, 113));
            }
        });
        removeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                removeButton.setBackground(new Color(200, 60, 60));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                removeButton.setBackground(new Color(240, 80, 80));
            }
        });
        sortBox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                sortBox.setBackground(new Color(230, 230, 255));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                sortBox.setBackground(Color.WHITE);
            }
        });
    }

    private void addTaskDialog() {
        String text = taskField.getText().trim();
        if (text.isEmpty() || text.equals(placeholder)) return;
        LocalDate dueDate = askForDueDate(null);
        if (dueDate == null && !confirmNoDueDate()) return;
        taskListModel.addTask(new Task(text, dueDate));
        taskField.setText("");
        taskField.setForeground(Color.BLACK);
    }

    private void editTaskDialog(int index) {
        Task t = taskListModel.getElementAt(index);
        String newText = (String) JOptionPane.showInputDialog(this, "Edit task:", "Edit Task", JOptionPane.PLAIN_MESSAGE, null, null, t.text);
        if (newText == null || newText.trim().isEmpty()) return;
        LocalDate newDueDate = askForDueDate(t.dueDate);
        if (newDueDate == null && !confirmNoDueDate()) return;
        taskListModel.editTask(index, newText.trim(), newDueDate);
    }

    private LocalDate askForDueDate(LocalDate current) {
        String prompt = "Enter due date (DD-MM-YYYY) or leave blank for none:";
        String initial = current == null ? "" : current.format(fmt);
        String input = (String) JOptionPane.showInputDialog(this, prompt, "Due Date", JOptionPane.PLAIN_MESSAGE, null, null, initial);
        if (input == null) return current; // Cancelled
        input = input.trim();
        if (input.isEmpty()) return null;
        try {
            return LocalDate.parse(input, fmt);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use DD-MM-YYYY.", "Error", JOptionPane.ERROR_MESSAGE);
            return askForDueDate(current);
        }
    }

    private boolean confirmNoDueDate() {
        int res = JOptionPane.showConfirmDialog(this, "No due date set. Continue?", "No Due Date", JOptionPane.YES_NO_OPTION);
        return res == JOptionPane.YES_OPTION;
    }

    private void removeTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex != -1) {
            taskListModel.removeTask(selectedIndex);
        }
    }


    static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            int w = getWidth();
            int h = getHeight();
            Color color1 = new Color(245, 250, 255);
            Color color2 = new Color(220, 230, 250);
            GradientPaint gp = new GradientPaint(0, 0, color1, 0, h, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
        }
    }

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            UIManager.put("Label.font", new Font("Segoe UI", Font.PLAIN, 13));
            UIManager.put("Button.font", new Font("Segoe UI", Font.PLAIN, 13));
            UIManager.put("ComboBox.font", new Font("Segoe UI", Font.PLAIN, 13));
            UIManager.put("TextField.font", new Font("Segoe UI", Font.PLAIN, 13));
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> {
            new ToDoListApp().setVisible(true);
        });
    }
} 